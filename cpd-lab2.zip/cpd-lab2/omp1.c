#include <stdio.h>
#include <omp.h>

int main() {
    int i;

    #pragma omp parallel
    {
        #pragma omp for nowait
        for (i = 0; i < 10; i++) {
            printf("Thread %d executando a iteração %d\n", omp_get_thread_num(), i);
        }

        #pragma omp barrier

        printf("Thread %d terminou seu trabalho!\n", omp_get_thread_num());
    }

    return 0;
}
