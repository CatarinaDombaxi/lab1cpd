#include <stdio.h>
#define SIZE 10
#define NUMITER 5
#define f(x,y) ((x+y)/2.0)

int main() {
    double V[SIZE];
    int i, iter;

    // Inicializa o vetor
    for (i = 0; i < SIZE; i++) {
        V[i] = i * 1.0;
    }

    // Loop serial
    for (iter = 0; iter < NUMITER; iter++) {
        for (i = 0; i < SIZE - 1; i++) {
            V[i] = f(V[i], V[i + 1]);
        }
    }

    // Exibir resultado
    for (i = 0; i < SIZE; i++) {
        printf("%f ", V[i]);
    }
    printf("\n");

    return 0;
}
