#include <stdio.h>
#include <omp.h>
#define SIZE 10
#define NUMITER 5
#define f(x,y) ((x+y)/2.0)

int main() {
    double V[2][SIZE];
    int i, iter, curr = 0;

    for (i = 0; i < SIZE; i++) {
        V[0][i] = i * 1.0;
    }

    for (iter = 0; iter < NUMITER; iter++) {
        int prev = curr;
        curr = 1 - curr; // Alterna entre 0 e 1

        #pragma omp parallel for
        for (i = 0; i < SIZE - 1; i++) {
            V[curr][i] = f(V[prev][i], V[prev][i + 1]);
        }
    }

    for (i = 0; i < SIZE; i++) {
        printf("%f ", V[curr][i]);
    }
    printf("\n");

    return 0;
}
