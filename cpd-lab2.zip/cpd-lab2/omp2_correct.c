#include <stdio.h>
#include <omp.h>
#define SIZE 10
#define NUMITER 5
#define f(x,y) ((x+y)/2.0)

int main() {
    double V[SIZE], V_old[SIZE];
    int i, iter;

    for (i = 0; i < SIZE; i++) {
        V[i] = i * 1.0;
    }

    for (iter = 0; iter < NUMITER; iter++) {
        // Copia V para V_old
        for (i = 0; i < SIZE; i++) {
            V_old[i] = V[i];
        }

        // Paraleliza o loop interno usando V_old para evitar dependência de dados
        #pragma omp parallel for
        for (i = 0; i < SIZE - 1; i++) {
            V[i] = f(V_old[i], V_old[i + 1]);
        }
    }

    for (i = 0; i < SIZE; i++) {
        printf("%f ", V[i]);
    }
    printf("\n");

    return 0;
}
