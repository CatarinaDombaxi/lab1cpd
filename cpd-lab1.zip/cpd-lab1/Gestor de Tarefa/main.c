#include "tasks.h"

int main() {
    task_list_t *task_list = create_task_list();
    char input[100];  // Buffer maior para armazenar toda a linha
    char command[10], id[50];
    int priority;

    printf("Bem-vindo ao Gestor de Tarefas! Digite um comando (new, list, complete, exit):\n");

    while (1) {
        printf("> ");
        fgets(input, sizeof(input), stdin);  // Captura toda a linha

        // Tenta extrair os par�metros corretamente
        if (sscanf(input, "%s %d %s", command, &priority, id) == 3 && strcmp(command, "new") == 0) {
            add_task(task_list, priority, id);
        } else if (sscanf(input, "%s %d", command, &priority) == 2 && strcmp(command, "list") == 0) {
            list_tasks(task_list, priority);
        } else if (sscanf(input, "%s %s", command, id) == 2 && strcmp(command, "complete") == 0) {
            complete_task(task_list, id);
        } else if (strcmp(input, "exit\n") == 0) {
            break;
        } else {
            printf("Comando inv�lido! Use: new <prioridade> <id>, list <prioridade>, complete <id>, exit.\n");
        }
    }

    free_task_list(task_list);
    printf("Gestor de Tarefas encerrado.\n");
    return 0;
}
