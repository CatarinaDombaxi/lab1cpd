#ifndef TASKS_H
#define TASKS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Estrutura de uma tarefa
typedef struct task {
    char id[50];
    int priority;
    time_t creation_time;
    struct task *next;
} task_t;

// Lista de tarefas
typedef struct {
    task_t *first;
} task_list_t;

// Funções do gestor de tarefas
task_list_t* create_task_list();
void add_task(task_list_t *list, int priority, char *id);
void list_tasks(task_list_t *list, int min_priority);
void complete_task(task_list_t *list, char *id);
void free_task_list(task_list_t *list);

#endif
