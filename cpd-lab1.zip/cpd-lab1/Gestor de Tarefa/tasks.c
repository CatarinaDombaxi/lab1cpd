#include "tasks.h"

// Criar uma nova lista de tarefas
task_list_t* create_task_list() {
    task_list_t *list = (task_list_t*) malloc(sizeof(task_list_t));
    list->first = NULL;
    return list;
}

// Adicionar uma nova tarefa à lista
void add_task(task_list_t *list, int priority, char *id) {
    task_t *new_task = (task_t*) malloc(sizeof(task_t));
    strcpy(new_task->id, id);
    new_task->priority = priority;
    new_task->creation_time = time(NULL);
    new_task->next = list->first;
    list->first = new_task;
    printf("Tarefa adicionada: %s (Prioridade %d)\n", id, priority);
}

// Listar tarefas com prioridade mínima
void list_tasks(task_list_t *list, int min_priority) {
    task_t *current = list->first;
    printf("Tarefas com prioridade >= %d:\n", min_priority);
    while (current != NULL) {
        if (current->priority >= min_priority) {
            printf("[%s] Prioridade: %d - Criada em %s", 
                current->id, current->priority, ctime(&(current->creation_time)));
        }
        current = current->next;
    }
}

// Remover uma tarefa pelo ID
void complete_task(task_list_t *list, char *id) {
    task_t *current = list->first;
    task_t *prev = NULL;

    while (current != NULL) {
        if (strcmp(current->id, id) == 0) {
            if (prev == NULL) {
                list->first = current->next;
            } else {
                prev->next = current->next;
            }
            free(current);
            printf("Tarefa concluída e removida: %s\n", id);
            return;
        }
        prev = current;
        current = current->next;
    }
    printf("Tarefa não encontrada: %s\n", id);
}

// Liberar a memória da lista
void free_task_list(task_list_t *list) {
    task_t *current = list->first;
    while (current != NULL) {
        task_t *temp = current;
        current = current->next;
        free(temp);
    }
    free(list);
}
