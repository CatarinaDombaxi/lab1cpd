#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SMALL_SIZE 1         // 1 byte (latência)
#define LARGE_SIZE (1024*1024) // 1 MB (largura de banda)
#define N_TESTS 1000

int main(int argc, char *argv[]) {
    int id, p, i;
    MPI_Status status;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &id);
    MPI_Comm_size(MPI_COMM_WORLD, &p);

    if (p < 2) {
        if (id == 0) printf("Este teste requer pelo menos 2 processos.\n");
        MPI_Finalize();
        return 1;
    }

    char *buffer = malloc(LARGE_SIZE);
    memset(buffer, 'a', LARGE_SIZE);

    double start, end;

    // ========== MEDIÇÃO DE LATÊNCIA ==========
    if (id == 0) {
        start = MPI_Wtime();
        for (i = 0; i < N_TESTS; i++) {
            MPI_Send(buffer, SMALL_SIZE, MPI_CHAR, 1, 0, MPI_COMM_WORLD);
            MPI_Recv(buffer, SMALL_SIZE, MPI_CHAR, 1, 0, MPI_COMM_WORLD, &status);
        }
        end = MPI_Wtime();
        double latency_us = (end - start) * 1e6 / (2 * N_TESTS);
        printf("Latência estimada: %.2f microssegundos\n", latency_us);
    } else if (id == 1) {
        for (i = 0; i < N_TESTS; i++) {
            MPI_Recv(buffer, SMALL_SIZE, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &status);
            MPI_Send(buffer, SMALL_SIZE, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);

    // ========== MEDIÇÃO DE LARGURA DE BANDA ==========
    if (id == 0) {
        start = MPI_Wtime();
        for (i = 0; i < N_TESTS; i++) {
            MPI_Send(buffer, LARGE_SIZE, MPI_CHAR, 1, 1, MPI_COMM_WORLD);
            MPI_Recv(buffer, LARGE_SIZE, MPI_CHAR, 1, 1, MPI_COMM_WORLD, &status);
        }
        end = MPI_Wtime();
        double total_MB = 2.0 * N_TESTS * LARGE_SIZE / (1024.0 * 1024.0);
        double time_sec = end - start;
        double bandwidth_MBps = total_MB / time_sec;
        printf("Largura de banda estimada: %.2f MB/s\n", bandwidth_MBps);
    } else if (id == 1) {
        for (i = 0; i < N_TESTS; i++) {
            MPI_Recv(buffer, LARGE_SIZE, MPI_CHAR, 0, 1, MPI_COMM_WORLD, &status);
            MPI_Send(buffer, LARGE_SIZE, MPI_CHAR, 0, 1, MPI_COMM_WORLD);
        }
    }

    free(buffer);
    MPI_Finalize();
    return 0;
}
