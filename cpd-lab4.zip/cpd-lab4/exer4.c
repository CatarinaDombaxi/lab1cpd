#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE (1<<20) // 1 milhão de floats (~4MB)

int main(int argc, char *argv[]) {
    int id, p;
    float *array;
    double start, end;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &id);
    MPI_Comm_size(MPI_COMM_WORLD, &p);

    array = (float*) malloc(ARRAY_SIZE * sizeof(float));
    if (id == 0) {
        for (int i = 0; i < ARRAY_SIZE; i++)
            array[i] = (float)i;
    }

    // ---------------- MPI_Bcast ----------------
    MPI_Barrier(MPI_COMM_WORLD);
    start = MPI_Wtime();
    MPI_Bcast(array, ARRAY_SIZE, MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);
    end = MPI_Wtime();

    if (id == 0)
        printf("Tempo com MPI_Bcast: %.6f segundos\n", end - start);

    // ---------------- MPI_Send / MPI_Recv ----------------
    MPI_Barrier(MPI_COMM_WORLD);
    start = MPI_Wtime();

    if (id == 0) {
        for (int dest = 1; dest < p; dest++) {
            MPI_Send(array, ARRAY_SIZE, MPI_FLOAT, dest, 0, MPI_COMM_WORLD);
        }
    } else {
        MPI_Recv(array, ARRAY_SIZE, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    end = MPI_Wtime();

    if (id == 0)
        printf("Tempo com MPI_Send individual: %.6f segundos\n", end - start);

    free(array);
    MPI_Finalize();
    return 0;
}
